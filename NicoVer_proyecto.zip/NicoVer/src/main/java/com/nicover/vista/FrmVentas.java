package com.nicover.vista;

import com.nicover.controlador.ClienteController;
import com.nicover.controlador.VentaController;
import com.nicover.modelo.Cliente;
import com.nicover.modelo.DetalleVenta;
import com.nicover.modelo.Usuario;
import com.nicover.modelo.Venta;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

/**
 * Vista del proceso principal: registrar una venta (RF-04, RF-05) y consultar
 * las ventas realizadas. La usan el cajero y el administrador.
 */
public class FrmVentas extends JFrame {

    // --- Pestaña "Nueva venta" ---
    private final JLabel lblCliente = new JLabel("Cliente:");
    private final JLabel lblCodigoProducto = new JLabel("Código producto:");
    private final JLabel lblCantidad = new JLabel("Cantidad:");
    private final JComboBox<Cliente> cmbCliente = new JComboBox<>();
    private final JTextField txtCodigoProducto = new JTextField(10);
    private final JTextField txtCantidad = new JTextField("1", 4);
    private final JButton btnAgregar = new JButton("Agregar");
    private final JButton btnQuitar = new JButton("Quitar seleccionado");
    private final DefaultTableModel modeloCarrito = new DefaultTableModel(
            new String[]{"Código", "Producto", "Cantidad", "Precio", "Subtotal"}, 0) {
        @Override
        public boolean isCellEditable(int fila, int columna) {
            return false;
        }
    };
    private final JTable tblCarrito = new JTable(modeloCarrito);
    private final JLabel lblSubtotal = new JLabel("Subtotal: $0");
    private final JLabel lblIva = new JLabel("IVA (19%): $0");
    private final JLabel lblTotal = new JLabel("TOTAL: $0");
    private final JLabel lblMetodoPago = new JLabel("Método de pago:");
    private final JLabel lblMontoRecibido = new JLabel("Monto recibido:");
    private final JLabel lblCambio = new JLabel("Cambio: $0");
    private final JComboBox<String> cmbMetodoPago = new JComboBox<>(new String[]{"Efectivo", "Transferencia", "Tarjeta"});
    private final JTextField txtMontoRecibido = new JTextField(10);
    private final JButton btnFinalizarVenta = new JButton("Finalizar venta");
    private final JButton btnCancelar = new JButton("Cancelar venta");

    // --- Pestaña "Consultar ventas" ---
    private final JButton btnActualizarLista = new JButton("Actualizar lista");
    private final DefaultTableModel modeloVentas = new DefaultTableModel(
            new String[]{"N.º", "Fecha", "Cliente", "Cajero", "Subtotal", "IVA", "Total", "Pago"}, 0) {
        @Override
        public boolean isCellEditable(int fila, int columna) {
            return false;
        }
    };
    private final JTable tblVentas = new JTable(modeloVentas);

    private final VentaController controlador;
    private final ClienteController clienteController = new ClienteController();

    public FrmVentas(Usuario usuario) {
        controlador = new VentaController(usuario);
        setTitle("NicoVer - Ventas (" + usuario.getNombreUsuario() + ")");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JTabbedPane pestanas = new JTabbedPane();
        pestanas.addTab("Nueva venta", crearPanelNuevaVenta());
        pestanas.addTab("Consultar ventas", crearPanelConsulta());
        add(pestanas);

        btnAgregar.addActionListener(e -> agregar());
        btnQuitar.addActionListener(e -> quitar());
        btnFinalizarVenta.addActionListener(e -> finalizar());
        btnCancelar.addActionListener(e -> reiniciar());
        btnActualizarLista.addActionListener(e -> cargarVentas());

        setSize(800, 560);
        setLocationRelativeTo(null);
        cargarClientes();
        cargarVentas();
    }

    private JPanel crearPanelNuevaVenta() {
        JPanel norte = new JPanel(new FlowLayout(FlowLayout.LEFT));
        norte.add(lblCliente);
        norte.add(cmbCliente);
        norte.add(lblCodigoProducto);
        norte.add(txtCodigoProducto);
        norte.add(lblCantidad);
        norte.add(txtCantidad);
        norte.add(btnAgregar);
        norte.add(btnQuitar);

        JPanel totales = new JPanel(new GridLayout(0, 1, 4, 4));
        totales.setBorder(new EmptyBorder(5, 10, 5, 10));
        totales.add(lblSubtotal);
        totales.add(lblIva);
        totales.add(lblTotal);
        JPanel pago = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pago.add(lblMetodoPago);
        pago.add(cmbMetodoPago);
        pago.add(lblMontoRecibido);
        pago.add(txtMontoRecibido);
        pago.add(lblCambio);
        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        acciones.add(btnFinalizarVenta);
        acciones.add(btnCancelar);

        JPanel sur = new JPanel(new GridLayout(0, 1));
        sur.add(totales);
        sur.add(pago);
        sur.add(acciones);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(norte, BorderLayout.NORTH);
        panel.add(new JScrollPane(tblCarrito), BorderLayout.CENTER);
        panel.add(sur, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel crearPanelConsulta() {
        JPanel norte = new JPanel(new FlowLayout(FlowLayout.LEFT));
        norte.add(btnActualizarLista);
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(norte, BorderLayout.NORTH);
        panel.add(new JScrollPane(tblVentas), BorderLayout.CENTER);
        return panel;
    }

    private void agregar() {
        int cantidad;
        try {
            cantidad = Integer.parseInt(txtCantidad.getText().trim());
        } catch (NumberFormatException ex) {
            error("La cantidad debe ser un número entero.");
            return;
        }
        String mensaje = controlador.agregarProducto(txtCodigoProducto.getText(), cantidad);
        if (!mensaje.isEmpty()) {
            error(mensaje);
            return;
        }
        txtCodigoProducto.setText("");
        txtCantidad.setText("1");
        refrescarCarrito();
        txtCodigoProducto.requestFocus();
    }

    private void quitar() {
        int fila = tblCarrito.getSelectedRow();
        if (fila < 0) {
            error("Seleccione una línea del carrito para quitar.");
            return;
        }
        controlador.quitarDetalle(fila);
        refrescarCarrito();
    }

    private void finalizar() {
        double monto;
        try {
            monto = Double.parseDouble(txtMontoRecibido.getText().trim());
        } catch (NumberFormatException ex) {
            error("Digite el monto recibido (solo números).");
            return;
        }
        Cliente cliente = (Cliente) cmbCliente.getSelectedItem();
        String mensaje = controlador.finalizarVenta(cliente, (String) cmbMetodoPago.getSelectedItem(), monto);
        if (!mensaje.isEmpty()) {
            error(mensaje);
            return;
        }
        Venta v = controlador.getVentaActual();
        JOptionPane.showMessageDialog(this, String.format(
                "Venta N.º %d registrada.%nTotal: $%,.0f%nCambio: $%,.0f", v.getIdVenta(), v.getTotal(), v.getCambio()));
        reiniciar();
        cargarVentas();
    }

    /** Empieza una venta nueva y deja la pantalla limpia. */
    private void reiniciar() {
        controlador.nuevaVenta();
        txtMontoRecibido.setText("");
        txtCodigoProducto.setText("");
        txtCantidad.setText("1");
        refrescarCarrito();
    }

    private void refrescarCarrito() {
        Venta v = controlador.getVentaActual();
        modeloCarrito.setRowCount(0);
        for (DetalleVenta d : v.getDetalles()) {
            modeloCarrito.addRow(new Object[]{d.getProducto().getCodigo(), d.getProducto().getNombre(),
                    d.getCantidad(), d.getPrecioUnitario(), d.getSubtotal()});
        }
        lblSubtotal.setText(String.format("Subtotal: $%,.0f", v.getSubtotal()));
        lblIva.setText(String.format("IVA (19%%): $%,.0f", v.getIva()));
        lblTotal.setText(String.format("TOTAL: $%,.0f", v.getTotal()));
        lblCambio.setText("Cambio: $0");
    }

    private void cargarClientes() {
        try {
            cmbCliente.removeAllItems();
            for (Cliente c : clienteController.listar("")) {
                cmbCliente.addItem(c);
            }
        } catch (SQLException ex) {
            error("No se pudieron cargar los clientes: " + ex.getMessage());
        }
    }

    private void cargarVentas() {
        try {
            DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
            modeloVentas.setRowCount(0);
            for (Venta v : controlador.listarVentas()) {
                modeloVentas.addRow(new Object[]{v.getIdVenta(), v.getFecha().format(f),
                        v.getCliente().getNombre(), v.getUsuario().getNombreUsuario(),
                        v.getSubtotal(), v.getIva(), v.getTotal(), v.getMetodoPago()});
            }
        } catch (SQLException ex) {
            error("No se pudieron consultar las ventas: " + ex.getMessage());
        }
    }

    private void error(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Atención", JOptionPane.WARNING_MESSAGE);
    }
}
