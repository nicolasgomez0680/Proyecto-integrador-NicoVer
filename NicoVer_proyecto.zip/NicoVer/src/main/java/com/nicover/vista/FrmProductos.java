package com.nicover.vista;

import com.nicover.controlador.ProductoController;
import com.nicover.modelo.Producto;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

/**
 * Vista CRUD de productos (RF-02). La usa el administrador.
 */
public class FrmProductos extends JFrame {

    private final JLabel lblCodigo = new JLabel("Código:");
    private final JLabel lblNombre = new JLabel("Nombre:");
    private final JLabel lblPrecioCosto = new JLabel("Precio costo:");
    private final JLabel lblPrecioVenta = new JLabel("Precio venta:");
    private final JLabel lblStock = new JLabel("Stock:");
    private final JLabel lblBuscar = new JLabel("Buscar:");
    private final JTextField txtCodigo = new JTextField(12);
    private final JTextField txtNombre = new JTextField(20);
    private final JTextField txtPrecioCosto = new JTextField(10);
    private final JTextField txtPrecioVenta = new JTextField(10);
    private final JTextField txtStock = new JTextField(6);
    private final JTextField txtBuscar = new JTextField(14);
    private final JButton btnGuardar = new JButton("Guardar");
    private final JButton btnActualizar = new JButton("Actualizar");
    private final JButton btnEliminar = new JButton("Eliminar");
    private final JButton btnBuscar = new JButton("Buscar");
    private final JButton btnLimpiar = new JButton("Limpiar");
    private final DefaultTableModel modeloTabla = new DefaultTableModel(
            new String[]{"ID", "Código", "Nombre", "Costo", "Venta", "Stock"}, 0) {
        @Override
        public boolean isCellEditable(int fila, int columna) {
            return false;
        }
    };
    private final JTable tblProductos = new JTable(modeloTabla);

    private final ProductoController controlador = new ProductoController();
    private List<Producto> productosEnTabla = new ArrayList<>();
    private int idSeleccionado = 0;

    public FrmProductos() {
        setTitle("NicoVer - Productos");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(new EmptyBorder(10, 10, 5, 10));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 4, 4, 4);
        g.anchor = GridBagConstraints.WEST;
        g.gridx = 0; g.gridy = 0; form.add(lblCodigo, g);
        g.gridx = 1; form.add(txtCodigo, g);
        g.gridx = 2; form.add(lblNombre, g);
        g.gridx = 3; form.add(txtNombre, g);
        g.gridx = 0; g.gridy = 1; form.add(lblPrecioCosto, g);
        g.gridx = 1; form.add(txtPrecioCosto, g);
        g.gridx = 2; form.add(lblPrecioVenta, g);
        g.gridx = 3; form.add(txtPrecioVenta, g);
        g.gridx = 0; g.gridy = 2; form.add(lblStock, g);
        g.gridx = 1; form.add(txtStock, g);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        botones.add(btnGuardar);
        botones.add(btnActualizar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);
        botones.add(lblBuscar);
        botones.add(txtBuscar);
        botones.add(btnBuscar);

        JPanel norte = new JPanel(new BorderLayout());
        norte.add(form, BorderLayout.CENTER);
        norte.add(botones, BorderLayout.SOUTH);

        add(norte, BorderLayout.NORTH);
        add(new JScrollPane(tblProductos), BorderLayout.CENTER);

        btnGuardar.addActionListener(e -> guardar());
        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> eliminar());
        btnBuscar.addActionListener(e -> cargarTabla(txtBuscar.getText()));
        btnLimpiar.addActionListener(e -> limpiar());
        tblProductos.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                mostrarSeleccionado();
            }
        });

        setSize(760, 480);
        setLocationRelativeTo(null);
        cargarTabla("");
    }

    /** Lee los campos del formulario; devuelve null si los números no son válidos. */
    private Producto leerFormulario() {
        try {
            Producto p = new Producto();
            p.setIdProducto(idSeleccionado);
            p.setCodigo(txtCodigo.getText());
            p.setNombre(txtNombre.getText());
            p.setPrecioCosto(Double.parseDouble(txtPrecioCosto.getText().trim()));
            p.setPrecioVenta(Double.parseDouble(txtPrecioVenta.getText().trim()));
            p.setStock(Integer.parseInt(txtStock.getText().trim()));
            return p;
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Precios y stock deben ser números válidos.",
                    "Datos inválidos", JOptionPane.WARNING_MESSAGE);
            return null;
        }
    }

    private void guardar() {
        Producto p = leerFormulario();
        if (p == null) return;
        p.setIdProducto(0);
        mostrarResultado(controlador.guardar(p), "Producto guardado correctamente.");
    }

    private void actualizar() {
        Producto p = leerFormulario();
        if (p == null) return;
        mostrarResultado(controlador.actualizar(p), "Producto actualizado correctamente.");
    }

    private void eliminar() {
        if (idSeleccionado > 0) {
            int r = JOptionPane.showConfirmDialog(this, "¿Eliminar el producto seleccionado?",
                    "Confirmar", JOptionPane.YES_NO_OPTION);
            if (r != JOptionPane.YES_OPTION) return;
        }
        mostrarResultado(controlador.eliminar(idSeleccionado), "Producto eliminado correctamente.");
    }

    /** Muestra el mensaje de error o de éxito y refresca la pantalla. */
    private void mostrarResultado(String error, String exito) {
        if (error.isEmpty()) {
            JOptionPane.showMessageDialog(this, exito);
            limpiar();
        } else {
            JOptionPane.showMessageDialog(this, error, "No se pudo completar", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarTabla(String filtro) {
        try {
            productosEnTabla = controlador.listar(filtro);
            modeloTabla.setRowCount(0);
            for (Producto p : productosEnTabla) {
                modeloTabla.addRow(new Object[]{p.getIdProducto(), p.getCodigo(), p.getNombre(),
                        p.getPrecioCosto(), p.getPrecioVenta(), p.getStock()});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al consultar: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void mostrarSeleccionado() {
        int fila = tblProductos.getSelectedRow();
        if (fila < 0 || fila >= productosEnTabla.size()) return;
        Producto p = productosEnTabla.get(fila);
        idSeleccionado = p.getIdProducto();
        txtCodigo.setText(p.getCodigo());
        txtNombre.setText(p.getNombre());
        txtPrecioCosto.setText(String.valueOf(p.getPrecioCosto()));
        txtPrecioVenta.setText(String.valueOf(p.getPrecioVenta()));
        txtStock.setText(String.valueOf(p.getStock()));
    }

    private void limpiar() {
        idSeleccionado = 0;
        txtCodigo.setText("");
        txtNombre.setText("");
        txtPrecioCosto.setText("");
        txtPrecioVenta.setText("");
        txtStock.setText("");
        txtBuscar.setText("");
        tblProductos.clearSelection();
        cargarTabla("");
    }
}
