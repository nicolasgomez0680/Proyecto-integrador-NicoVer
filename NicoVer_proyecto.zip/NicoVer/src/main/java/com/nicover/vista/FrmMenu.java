package com.nicover.vista;

import com.nicover.modelo.Usuario;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

/**
 * Menú principal. Lo ven el administrador (todos los módulos) y el cajero
 * (solo clientes y ventas).
 */
public class FrmMenu extends JFrame {

    private final JLabel lblBienvenida;
    private final JButton btnProductos = new JButton("Productos");
    private final JButton btnClientes = new JButton("Clientes");
    private final JButton btnVentas = new JButton("Ventas");
    private final JButton btnCerrarSesion = new JButton("Cerrar sesión");

    private final Usuario usuario;

    public FrmMenu(Usuario usuario) {
        this.usuario = usuario;
        setTitle("NicoVer - Menú principal");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        lblBienvenida = new JLabel("Bienvenido, " + usuario.getNombreUsuario()
                + " (" + usuario.getRol() + ")", SwingConstants.CENTER);

        JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
        panel.setBorder(new EmptyBorder(20, 40, 20, 40));
        panel.add(lblBienvenida);
        panel.add(btnProductos);
        panel.add(btnClientes);
        panel.add(btnVentas);
        panel.add(btnCerrarSesion);

        // El cajero no administra el inventario
        btnProductos.setEnabled(usuario.esAdministrador());

        btnProductos.addActionListener(e -> new FrmProductos().setVisible(true));
        btnClientes.addActionListener(e -> new FrmClientes().setVisible(true));
        btnVentas.addActionListener(e -> new FrmVentas(this.usuario).setVisible(true));
        btnCerrarSesion.addActionListener(e -> {
            new FrmLogin().setVisible(true);
            dispose();
        });

        setContentPane(panel);
        pack();
        setSize(Math.max(getWidth(), 360), getHeight());
        setLocationRelativeTo(null);
    }
}
