package com.nicover.vista;

import com.nicover.controlador.LoginController;
import com.nicover.modelo.Usuario;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

/**
 * Ventana de inicio de sesión (RF-01). La ven todos los usuarios al abrir el sistema.
 */
public class FrmLogin extends JFrame {

    private final JLabel lblTitulo = new JLabel("NicoVer - Iniciar sesión", SwingConstants.CENTER);
    private final JLabel lblUsuario = new JLabel("Usuario:");
    private final JLabel lblClave = new JLabel("Clave:");
    private final JTextField txtUsuario = new JTextField(18);
    private final JPasswordField txtClave = new JPasswordField(18);
    private final JButton btnIngresar = new JButton("Ingresar");
    private final JButton btnSalir = new JButton("Salir");

    private final LoginController controlador = new LoginController();

    public FrmLogin() {
        setTitle("NicoVer - Inicio de sesión");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new EmptyBorder(20, 25, 20, 25));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 6, 6, 6);
        g.fill = GridBagConstraints.HORIZONTAL;

        g.gridx = 0; g.gridy = 0; g.gridwidth = 2;
        lblTitulo.setFont(lblTitulo.getFont().deriveFont(18f));
        panel.add(lblTitulo, g);
        g.gridwidth = 1;
        g.gridy = 1; panel.add(lblUsuario, g);
        g.gridx = 1; panel.add(txtUsuario, g);
        g.gridx = 0; g.gridy = 2; panel.add(lblClave, g);
        g.gridx = 1; panel.add(txtClave, g);
        g.gridx = 0; g.gridy = 3; panel.add(btnIngresar, g);
        g.gridx = 1; panel.add(btnSalir, g);

        btnIngresar.addActionListener(e -> ingresar());
        btnSalir.addActionListener(e -> System.exit(0));
        getRootPane().setDefaultButton(btnIngresar);   // Enter = Ingresar

        setContentPane(panel);
        pack();
        setLocationRelativeTo(null);
    }

    /** Valida las credenciales y abre el menú principal si son correctas. */
    private void ingresar() {
        try {
            Usuario u = controlador.iniciarSesion(txtUsuario.getText(), new String(txtClave.getPassword()));
            if (u == null) {
                JOptionPane.showMessageDialog(this, "Usuario o clave incorrectos.",
                        "Acceso denegado", JOptionPane.ERROR_MESSAGE);
                txtClave.setText("");
                return;
            }
            new FrmMenu(u).setVisible(true);
            dispose();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo conectar a la base de datos:\n" + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
