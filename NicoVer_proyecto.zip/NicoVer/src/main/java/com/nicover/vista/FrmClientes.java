package com.nicover.vista;

import com.nicover.controlador.ClienteController;
import com.nicover.modelo.Cliente;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

/**
 * Vista CRUD de clientes (RF-03). La usan el administrador y el cajero.
 */
public class FrmClientes extends JFrame {

    private final JLabel lblDocumento = new JLabel("Documento:");
    private final JLabel lblNombre = new JLabel("Nombre:");
    private final JLabel lblTelefono = new JLabel("Teléfono:");
    private final JLabel lblDireccion = new JLabel("Dirección:");
    private final JLabel lblBuscar = new JLabel("Buscar:");
    private final JTextField txtDocumento = new JTextField(12);
    private final JTextField txtNombre = new JTextField(20);
    private final JTextField txtTelefono = new JTextField(12);
    private final JTextField txtDireccion = new JTextField(20);
    private final JTextField txtBuscar = new JTextField(14);
    private final JCheckBox chkAutorizaDatos = new JCheckBox(
            "El cliente autoriza el tratamiento de sus datos personales (Ley 1581 de 2012)");
    private final JButton btnGuardar = new JButton("Guardar");
    private final JButton btnActualizar = new JButton("Actualizar");
    private final JButton btnEliminar = new JButton("Eliminar");
    private final JButton btnBuscar = new JButton("Buscar");
    private final JButton btnLimpiar = new JButton("Limpiar");
    private final DefaultTableModel modeloTabla = new DefaultTableModel(
            new String[]{"ID", "Documento", "Nombre", "Teléfono", "Dirección", "Autoriza datos"}, 0) {
        @Override
        public boolean isCellEditable(int fila, int columna) {
            return false;
        }
    };
    private final JTable tblClientes = new JTable(modeloTabla);

    private final ClienteController controlador = new ClienteController();
    private List<Cliente> clientesEnTabla = new ArrayList<>();
    private int idSeleccionado = 0;

    public FrmClientes() {
        setTitle("NicoVer - Clientes");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(new EmptyBorder(10, 10, 5, 10));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 4, 4, 4);
        g.anchor = GridBagConstraints.WEST;
        g.gridx = 0; g.gridy = 0; form.add(lblDocumento, g);
        g.gridx = 1; form.add(txtDocumento, g);
        g.gridx = 2; form.add(lblNombre, g);
        g.gridx = 3; form.add(txtNombre, g);
        g.gridx = 0; g.gridy = 1; form.add(lblTelefono, g);
        g.gridx = 1; form.add(txtTelefono, g);
        g.gridx = 2; form.add(lblDireccion, g);
        g.gridx = 3; form.add(txtDireccion, g);
        g.gridx = 0; g.gridy = 2; g.gridwidth = 4; form.add(chkAutorizaDatos, g);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.LEFT));
        botones.add(btnGuardar);
        botones.add(btnActualizar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);
        botones.add(lblBuscar);
        botones.add(txtBuscar);
        botones.add(btnBuscar);

        JPanel norte = new JPanel(new BorderLayout());
        norte.add(form, BorderLayout.CENTER);
        norte.add(botones, BorderLayout.SOUTH);

        add(norte, BorderLayout.NORTH);
        add(new JScrollPane(tblClientes), BorderLayout.CENTER);

        btnGuardar.addActionListener(e -> guardar());
        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> eliminar());
        btnBuscar.addActionListener(e -> cargarTabla(txtBuscar.getText()));
        btnLimpiar.addActionListener(e -> limpiar());
        tblClientes.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                mostrarSeleccionado();
            }
        });

        setSize(800, 480);
        setLocationRelativeTo(null);
        cargarTabla("");
    }

    private Cliente leerFormulario() {
        Cliente c = new Cliente();
        c.setIdCliente(idSeleccionado);
        c.setDocumento(txtDocumento.getText());
        c.setNombre(txtNombre.getText());
        c.setTelefono(txtTelefono.getText());
        c.setDireccion(txtDireccion.getText());
        c.setAceptaDatos(chkAutorizaDatos.isSelected());
        return c;
    }

    private void guardar() {
        Cliente c = leerFormulario();
        c.setIdCliente(0);
        mostrarResultado(controlador.guardar(c), "Cliente guardado correctamente.");
    }

    private void actualizar() {
        mostrarResultado(controlador.actualizar(leerFormulario()), "Cliente actualizado correctamente.");
    }

    private void eliminar() {
        if (idSeleccionado > 0) {
            int r = JOptionPane.showConfirmDialog(this, "¿Eliminar el cliente seleccionado?",
                    "Confirmar", JOptionPane.YES_NO_OPTION);
            if (r != JOptionPane.YES_OPTION) return;
        }
        mostrarResultado(controlador.eliminar(idSeleccionado), "Cliente eliminado correctamente.");
    }

    /** Muestra el mensaje de error o de éxito y refresca la pantalla. */
    private void mostrarResultado(String error, String exito) {
        if (error.isEmpty()) {
            JOptionPane.showMessageDialog(this, exito);
            limpiar();
        } else {
            JOptionPane.showMessageDialog(this, error, "No se pudo completar", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void cargarTabla(String filtro) {
        try {
            clientesEnTabla = controlador.listar(filtro);
            modeloTabla.setRowCount(0);
            for (Cliente c : clientesEnTabla) {
                modeloTabla.addRow(new Object[]{c.getIdCliente(), c.getDocumento(), c.getNombre(),
                        c.getTelefono(), c.getDireccion(), c.isAceptaDatos() ? "Sí" : "No"});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al consultar: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void mostrarSeleccionado() {
        int fila = tblClientes.getSelectedRow();
        if (fila < 0 || fila >= clientesEnTabla.size()) return;
        Cliente c = clientesEnTabla.get(fila);
        idSeleccionado = c.getIdCliente();
        txtDocumento.setText(c.getDocumento());
        txtNombre.setText(c.getNombre());
        txtTelefono.setText(c.getTelefono());
        txtDireccion.setText(c.getDireccion());
        chkAutorizaDatos.setSelected(c.isAceptaDatos());
    }

    private void limpiar() {
        idSeleccionado = 0;
        txtDocumento.setText("");
        txtNombre.setText("");
        txtTelefono.setText("");
        txtDireccion.setText("");
        txtBuscar.setText("");
        chkAutorizaDatos.setSelected(false);
        tblClientes.clearSelection();
        cargarTabla("");
    }
}
