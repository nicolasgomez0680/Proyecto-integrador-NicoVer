package com.nicover;

import com.nicover.vista.FrmLogin;
import javax.swing.SwingUtilities;

/**
 * Punto de entrada de NicoVer: abre la ventana de inicio de sesión.
 */
public class Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FrmLogin().setVisible(true));
    }
}
