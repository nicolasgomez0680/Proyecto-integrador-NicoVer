package com.nicover.modelo;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Representa a una persona que usa el sistema (administrador o cajero).
 * Su responsabilidad es guardar los datos de acceso y el rol, que define
 * a qué módulos puede entrar.
 */
public class Usuario {

    private int idUsuario;
    private String nombreUsuario;
    private String clave;   // se guarda cifrada (SHA-256)
    private String rol;     // "ADMINISTRADOR" o "CAJERO"

    public Usuario() {
    }

    public Usuario(int idUsuario, String nombreUsuario, String clave, String rol) {
        this.idUsuario = idUsuario;
        this.nombreUsuario = nombreUsuario;
        this.clave = clave;
        this.rol = rol;
    }

    /** Indica si el usuario tiene rol de administrador. */
    public boolean esAdministrador() {
        return "ADMINISTRADOR".equals(rol);
    }

    /**
     * Cifra una clave con SHA-256 para compararla o guardarla (RNF-03).
     * @param clave texto de la clave sin cifrar
     * @return clave cifrada en hexadecimal (64 caracteres)
     */
    public static String encriptarClave(String clave) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(clave.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 no disponible", e);
        }
    }

    // Getters y setters
    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }
    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }
    public String getClave() { return clave; }
    public void setClave(String clave) { this.clave = clave; }
    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }
}
