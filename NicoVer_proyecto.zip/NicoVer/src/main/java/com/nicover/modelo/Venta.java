package com.nicover.modelo;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Representa una venta realizada en el punto de pago. Agrupa al cliente, al
 * usuario que la registró, sus detalles y los totales (subtotal, IVA, total,
 * pago y cambio).
 */
public class Venta {

    /** Porcentaje de IVA aplicado a la venta (19 %). */
    public static final double IVA = 0.19;

    private int idVenta;
    private LocalDateTime fecha;
    private Cliente cliente;
    private Usuario usuario;
    private List<DetalleVenta> detalles = new ArrayList<>();
    private double subtotal;
    private double iva;
    private double total;
    private String metodoPago;
    private double montoRecibido;
    private double cambio;

    public Venta() {
        this.fecha = LocalDateTime.now();
    }

    /**
     * Agrega un producto al carrito de la venta.
     * Si el producto ya estaba, suma la cantidad a la línea existente.
     * No permite cantidades menores o iguales a cero ni superiores al stock.
     * @param producto producto a vender
     * @param cantidad unidades solicitadas
     * @return true si se agregó; false si la cantidad no es válida o no hay stock
     */
    public boolean agregarDetalle(Producto producto, int cantidad) {
        if (producto == null || cantidad <= 0) {
            return false;
        }
        for (DetalleVenta d : detalles) {
            if (d.getProducto().getIdProducto() == producto.getIdProducto()) {
                int nuevaCantidad = d.getCantidad() + cantidad;
                if (nuevaCantidad > producto.getStock()) {
                    return false;
                }
                d.setCantidad(nuevaCantidad);
                d.calcularSubtotal();
                calcularTotales();
                return true;
            }
        }
        if (cantidad > producto.getStock()) {
            return false;
        }
        detalles.add(new DetalleVenta(producto, cantidad));
        calcularTotales();
        return true;
    }

    /**
     * Calcula el subtotal (suma de los detalles), el IVA y el total a pagar.
     * @return el total a pagar; los tres valores quedan guardados en la venta
     */
    public double calcularTotales() {
        double suma = 0;
        for (DetalleVenta d : detalles) {
            suma = suma + d.calcularSubtotal();
        }
        subtotal = redondear(suma);
        iva = redondear(subtotal * IVA);
        total = redondear(subtotal + iva);
        return total;
    }

    /**
     * Registra el pago de la venta y calcula el cambio.
     * @param metodo método de pago (Efectivo, Transferencia...)
     * @param montoRecibido dinero entregado por el cliente
     * @return true si el monto cubre el total; false si es insuficiente
     */
    public boolean registrarPago(String metodo, double montoRecibido) {
        if (detalles.isEmpty() || montoRecibido < total) {
            return false;
        }
        this.metodoPago = metodo;
        this.montoRecibido = montoRecibido;
        this.cambio = redondear(montoRecibido - total);
        return true;
    }

    private double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }

    // Getters y setters
    public int getIdVenta() { return idVenta; }
    public void setIdVenta(int idVenta) { this.idVenta = idVenta; }
    public LocalDateTime getFecha() { return fecha; }
    public void setFecha(LocalDateTime fecha) { this.fecha = fecha; }
    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
    public List<DetalleVenta> getDetalles() { return detalles; }
    public void setDetalles(List<DetalleVenta> detalles) { this.detalles = detalles; }
    public double getSubtotal() { return subtotal; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }
    public double getIva() { return iva; }
    public void setIva(double iva) { this.iva = iva; }
    public double getTotal() { return total; }
    public void setTotal(double total) { this.total = total; }
    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }
    public double getMontoRecibido() { return montoRecibido; }
    public void setMontoRecibido(double montoRecibido) { this.montoRecibido = montoRecibido; }
    public double getCambio() { return cambio; }
    public void setCambio(double cambio) { this.cambio = cambio; }
}
