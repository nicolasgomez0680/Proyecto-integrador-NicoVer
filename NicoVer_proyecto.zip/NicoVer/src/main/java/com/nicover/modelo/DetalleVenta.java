package com.nicover.modelo;

/**
 * Representa una línea de una venta: un producto, la cantidad vendida y el
 * precio al que se vendió. Solo existe como parte de una Venta (composición).
 */
public class DetalleVenta {

    private Producto producto;
    private int cantidad;
    private double precioUnitario;
    private double subtotal;

    public DetalleVenta() {
    }

    public DetalleVenta(Producto producto, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.precioUnitario = producto.getPrecioVenta();
        calcularSubtotal();
    }

    /**
     * Calcula el subtotal de la línea (precio unitario x cantidad).
     * @return el subtotal calculado, que también queda guardado en el objeto
     */
    public double calcularSubtotal() {
        subtotal = precioUnitario * cantidad;
        return subtotal;
    }

    // Getters y setters
    public Producto getProducto() { return producto; }
    public void setProducto(Producto producto) { this.producto = producto; }
    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public double getPrecioUnitario() { return precioUnitario; }
    public void setPrecioUnitario(double precioUnitario) { this.precioUnitario = precioUnitario; }
    public double getSubtotal() { return subtotal; }
    public void setSubtotal(double subtotal) { this.subtotal = subtotal; }
}
