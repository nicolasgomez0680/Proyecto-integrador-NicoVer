package com.nicover.modelo;

/**
 * Representa un artículo del inventario de la tienda. Guarda su código,
 * precios y las unidades disponibles (stock).
 */
public class Producto {

    private int idProducto;
    private String codigo;
    private String nombre;
    private double precioCosto;
    private double precioVenta;
    private int stock;

    public Producto() {
    }

    public Producto(int idProducto, String codigo, String nombre, double precioCosto,
                    double precioVenta, int stock) {
        this.idProducto = idProducto;
        this.codigo = codigo;
        this.nombre = nombre;
        this.precioCosto = precioCosto;
        this.precioVenta = precioVenta;
        this.stock = stock;
    }

    /**
     * Valida los datos del producto antes de guardarlo.
     * Reglas: código y nombre obligatorios, precios positivos,
     * precio de venta mayor o igual al costo y stock no negativo.
     * @return texto con el error encontrado, o cadena vacía si todo está bien
     */
    public String validarDatos() {
        if (codigo == null || codigo.trim().isEmpty()) {
            return "El código es obligatorio.";
        }
        if (nombre == null || nombre.trim().isEmpty()) {
            return "El nombre es obligatorio.";
        }
        if (precioCosto <= 0 || precioVenta <= 0) {
            return "Los precios deben ser mayores que cero.";
        }
        if (precioVenta < precioCosto) {
            return "El precio de venta no puede ser menor que el precio de costo.";
        }
        if (stock < 0) {
            return "El stock no puede ser negativo.";
        }
        return "";
    }

    /**
     * Descuenta unidades del stock cuando se vende el producto.
     * @param cantidad unidades a descontar
     * @return true si había stock suficiente y se descontó; false si no
     */
    public boolean descontarStock(int cantidad) {
        if (cantidad <= 0 || cantidad > stock) {
            return false;
        }
        stock = stock - cantidad;
        return true;
    }

    // Getters y setters
    public int getIdProducto() { return idProducto; }
    public void setIdProducto(int idProducto) { this.idProducto = idProducto; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public double getPrecioCosto() { return precioCosto; }
    public void setPrecioCosto(double precioCosto) { this.precioCosto = precioCosto; }
    public double getPrecioVenta() { return precioVenta; }
    public void setPrecioVenta(double precioVenta) { this.precioVenta = precioVenta; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
}
