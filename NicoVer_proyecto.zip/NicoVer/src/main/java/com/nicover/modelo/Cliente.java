package com.nicover.modelo;

/**
 * Representa a un cliente de la tienda. Guarda sus datos de contacto y si
 * autorizó el tratamiento de sus datos personales (Ley 1581 de 2012).
 */
public class Cliente {

    private int idCliente;
    private String documento;
    private String nombre;
    private String telefono;
    private String direccion;
    private boolean aceptaDatos;

    public Cliente() {
    }

    public Cliente(int idCliente, String documento, String nombre, String telefono,
                   String direccion, boolean aceptaDatos) {
        this.idCliente = idCliente;
        this.documento = documento;
        this.nombre = nombre;
        this.telefono = telefono;
        this.direccion = direccion;
        this.aceptaDatos = aceptaDatos;
    }

    /**
     * Revisa que los datos del cliente sean válidos antes de guardarlos.
     * Reglas: documento numérico, nombre obligatorio y autorización de datos marcada.
     * @return texto con el error encontrado, o cadena vacía si todo está bien
     */
    public String validarDatos() {
        if (documento == null || documento.trim().isEmpty()) {
            return "El documento es obligatorio.";
        }
        if (!documento.trim().matches("\\d{5,15}")) {
            return "El documento debe tener solo números (5 a 15 dígitos).";
        }
        if (nombre == null || nombre.trim().isEmpty()) {
            return "El nombre es obligatorio.";
        }
        if (telefono != null && !telefono.trim().isEmpty() && !telefono.trim().matches("\\d{7,10}")) {
            return "El teléfono debe tener entre 7 y 10 dígitos.";
        }
        if (!aceptaDatos) {
            return "Debe marcarse la autorización de tratamiento de datos (Ley 1581 de 2012).";
        }
        return "";
    }

    /** Texto que se muestra en las listas desplegables. */
    @Override
    public String toString() {
        return nombre + " (" + documento + ")";
    }

    // Getters y setters
    public int getIdCliente() { return idCliente; }
    public void setIdCliente(int idCliente) { this.idCliente = idCliente; }
    public String getDocumento() { return documento; }
    public void setDocumento(String documento) { this.documento = documento; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
    public boolean isAceptaDatos() { return aceptaDatos; }
    public void setAceptaDatos(boolean aceptaDatos) { this.aceptaDatos = aceptaDatos; }
}
