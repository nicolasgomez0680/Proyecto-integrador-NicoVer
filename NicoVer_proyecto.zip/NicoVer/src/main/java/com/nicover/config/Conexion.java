package com.nicover.config;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Clase de configuración que entrega la conexión a la base de datos MySQL.
 * Lee la URL, el usuario y la clave desde el archivo db.properties para no
 * dejar contraseñas escritas en el código ni en el repositorio.
 */
public class Conexion {

    private static final String ARCHIVO = "db.properties";

    /**
     * Abre una conexión nueva a nicover_db.
     * @return conexión activa a MySQL
     * @throws SQLException si no se puede leer la configuración o conectar
     */
    public static Connection getConexion() throws SQLException {
        Properties p = new Properties();
        try (FileInputStream in = new FileInputStream(ARCHIVO)) {
            p.load(in);
        } catch (IOException e) {
            throw new SQLException("No se encontró el archivo " + ARCHIVO
                    + " en la raíz del proyecto (copie db.properties.example).", e);
        }
        return DriverManager.getConnection(
                p.getProperty("url"), p.getProperty("user"), p.getProperty("password"));
    }
}
