package com.nicover.controlador;

import com.nicover.modelo.Cliente;
import com.nicover.modelo.Producto;
import com.nicover.modelo.Usuario;
import com.nicover.modelo.Venta;
import com.nicover.repositorio.ProductoRepository;
import com.nicover.repositorio.VentaRepository;
import java.sql.SQLException;
import java.util.List;

/**
 * Controlador del proceso principal: registrar una venta (RF-04 y RF-05).
 * Mantiene la venta en curso (el "carrito") hasta que se finaliza.
 */
public class VentaController {

    private final ProductoRepository productoRepo = new ProductoRepository();
    private final VentaRepository ventaRepo = new VentaRepository();
    private final Usuario usuario;
    private Venta ventaActual;

    public VentaController(Usuario usuario) {
        this.usuario = usuario;
        this.ventaActual = new Venta();
    }

    /**
     * Busca el producto por código y lo agrega al carrito.
     * @param codigo código digitado
     * @param cantidad unidades pedidas
     * @return cadena vacía si se agregó; si no, el mensaje de error
     */
    public String agregarProducto(String codigo, int cantidad) {
        if (codigo == null || codigo.trim().isEmpty()) {
            return "Digite el código del producto.";
        }
        try {
            Producto p = productoRepo.buscarPorCodigo(codigo);
            if (p == null) {
                return "No existe un producto con el código " + codigo.trim() + ".";
            }
            if (!ventaActual.agregarDetalle(p, cantidad)) {
                return "Cantidad no válida o stock insuficiente (disponible: " + p.getStock() + ").";
            }
            return "";
        } catch (SQLException e) {
            return "Error de base de datos: " + e.getMessage();
        }
    }

    /** Quita del carrito la línea que está en la posición indicada. */
    public void quitarDetalle(int posicion) {
        if (posicion >= 0 && posicion < ventaActual.getDetalles().size()) {
            ventaActual.getDetalles().remove(posicion);
            ventaActual.calcularTotales();
        }
    }

    /**
     * Finaliza la venta: registra el pago, calcula el cambio, guarda en MySQL
     * y descuenta el stock.
     * @return cadena vacía si todo salió bien; si no, el mensaje de error
     */
    public String finalizarVenta(Cliente cliente, String metodoPago, double montoRecibido) {
        if (cliente == null) {
            return "Seleccione un cliente.";
        }
        if (ventaActual.getDetalles().isEmpty()) {
            return "El carrito está vacío.";
        }
        ventaActual.setCliente(cliente);
        ventaActual.setUsuario(usuario);
        ventaActual.calcularTotales();
        if (!ventaActual.registrarPago(metodoPago, montoRecibido)) {
            return "El monto recibido es menor al total a pagar.";
        }
        try {
            return ventaRepo.registrarVenta(ventaActual) ? ""
                    : "No se pudo registrar: el stock cambió y ya no alcanza.";
        } catch (SQLException e) {
            return "Error de base de datos: " + e.getMessage();
        }
    }

    /** Descarta la venta en curso y empieza una nueva. */
    public void nuevaVenta() {
        ventaActual = new Venta();
    }

    public Venta getVentaActual() {
        return ventaActual;
    }

    /** Consulta las ventas ya registradas. */
    public List<Venta> listarVentas() throws SQLException {
        return ventaRepo.listar();
    }
}
