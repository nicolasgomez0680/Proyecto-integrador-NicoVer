package com.nicover.controlador;

import com.nicover.modelo.Producto;
import com.nicover.repositorio.ProductoRepository;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

/**
 * Controlador del módulo de productos (RF-02). Recibe lo que pide la vista,
 * valida con el modelo y llama al repositorio. Las operaciones que modifican
 * datos devuelven un texto: vacío si salió bien, o el mensaje de error.
 */
public class ProductoController {

    private final ProductoRepository repositorio = new ProductoRepository();

    /** Valida y guarda un producto nuevo. */
    public String guardar(Producto p) {
        String error = p.validarDatos();
        if (!error.isEmpty()) {
            return error;
        }
        try {
            return repositorio.guardar(p) ? "" : "Ya existe un producto con el código " + p.getCodigo() + ".";
        } catch (SQLException e) {
            return "Error de base de datos: " + e.getMessage();
        }
    }

    /** Valida y actualiza un producto existente. */
    public String actualizar(Producto p) {
        if (p.getIdProducto() <= 0) {
            return "Seleccione un producto de la tabla para actualizar.";
        }
        String error = p.validarDatos();
        if (!error.isEmpty()) {
            return error;
        }
        try {
            return repositorio.actualizar(p) ? "" : "Otro producto ya usa el código " + p.getCodigo() + ".";
        } catch (SQLException e) {
            return "Error de base de datos: " + e.getMessage();
        }
    }

    /** Elimina un producto; no es posible si ya fue vendido. */
    public String eliminar(int idProducto) {
        if (idProducto <= 0) {
            return "Seleccione un producto de la tabla para eliminar.";
        }
        try {
            return repositorio.eliminar(idProducto) ? "" : "El producto no existe.";
        } catch (SQLIntegrityConstraintViolationException e) {
            return "No se puede eliminar: el producto ya tiene ventas registradas.";
        } catch (SQLException e) {
            return "Error de base de datos: " + e.getMessage();
        }
    }

    /** Lista los productos que coinciden con el filtro (vacío = todos). */
    public List<Producto> listar(String filtro) throws SQLException {
        return repositorio.listar(filtro);
    }
}
