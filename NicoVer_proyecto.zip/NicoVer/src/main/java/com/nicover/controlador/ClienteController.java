package com.nicover.controlador;

import com.nicover.modelo.Cliente;
import com.nicover.repositorio.ClienteRepository;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.List;

/**
 * Controlador del módulo de clientes (RF-03). Valida con el modelo y llama al
 * repositorio. Las operaciones que modifican datos devuelven un texto: vacío
 * si salió bien, o el mensaje de error.
 */
public class ClienteController {

    private final ClienteRepository repositorio = new ClienteRepository();

    /** Valida y guarda un cliente nuevo. */
    public String guardar(Cliente c) {
        String error = c.validarDatos();
        if (!error.isEmpty()) {
            return error;
        }
        try {
            return repositorio.guardar(c) ? "" : "Ya existe un cliente con el documento " + c.getDocumento() + ".";
        } catch (SQLException e) {
            return "Error de base de datos: " + e.getMessage();
        }
    }

    /** Valida y actualiza un cliente existente. */
    public String actualizar(Cliente c) {
        if (c.getIdCliente() <= 0) {
            return "Seleccione un cliente de la tabla para actualizar.";
        }
        String error = c.validarDatos();
        if (!error.isEmpty()) {
            return error;
        }
        try {
            return repositorio.actualizar(c) ? "" : "Otro cliente ya usa el documento " + c.getDocumento() + ".";
        } catch (SQLException e) {
            return "Error de base de datos: " + e.getMessage();
        }
    }

    /** Elimina un cliente; no es posible si ya tiene ventas. */
    public String eliminar(int idCliente) {
        if (idCliente <= 0) {
            return "Seleccione un cliente de la tabla para eliminar.";
        }
        try {
            return repositorio.eliminar(idCliente) ? "" : "El cliente no existe.";
        } catch (SQLIntegrityConstraintViolationException e) {
            return "No se puede eliminar: el cliente ya tiene ventas registradas.";
        } catch (SQLException e) {
            return "Error de base de datos: " + e.getMessage();
        }
    }

    /** Lista los clientes que coinciden con el filtro (vacío = todos). */
    public List<Cliente> listar(String filtro) throws SQLException {
        return repositorio.listar(filtro);
    }
}
