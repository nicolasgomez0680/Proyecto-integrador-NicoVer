package com.nicover.controlador;

import com.nicover.modelo.Usuario;
import com.nicover.repositorio.UsuarioRepository;
import java.sql.SQLException;

/**
 * Controlador del inicio de sesión: valida lo digitado y consulta al repositorio.
 */
public class LoginController {

    private final UsuarioRepository repositorio = new UsuarioRepository();

    /**
     * Intenta iniciar sesión (RF-01).
     * @param nombreUsuario usuario digitado
     * @param clave clave digitada
     * @return el Usuario autenticado, o null si los datos son incorrectos o están vacíos
     * @throws SQLException si no se puede consultar la base de datos
     */
    public Usuario iniciarSesion(String nombreUsuario, String clave) throws SQLException {
        if (nombreUsuario == null || nombreUsuario.trim().isEmpty()
                || clave == null || clave.isEmpty()) {
            return null;
        }
        return repositorio.autenticar(nombreUsuario.trim(), clave);
    }
}
