package com.nicover.repositorio;

import com.nicover.config.Conexion;
import com.nicover.modelo.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Repositorio de productos: realiza el CRUD sobre la tabla producto.
 */
public class ProductoRepository {

    /**
     * Inserta un producto nuevo (Create).
     * @param p producto a guardar
     * @return true si se guardó; false si ya existe otro producto con ese código
     * @throws SQLException si ocurre un error con la base de datos
     */
    public boolean guardar(Producto p) throws SQLException {
        if (existeCodigo(p.getCodigo(), 0)) {
            return false;
        }
        String sql = "INSERT INTO producto (codigo, nombre, precio_costo, precio_venta, stock) "
                   + "VALUES (?, ?, ?, ?, ?)";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getCodigo().trim());
            ps.setString(2, p.getNombre().trim());
            ps.setDouble(3, p.getPrecioCosto());
            ps.setDouble(4, p.getPrecioVenta());
            ps.setInt(5, p.getStock());
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Modifica un producto existente (Update).
     * @param p producto con los datos nuevos (debe traer su idProducto)
     * @return true si se actualizó; false si el código ya lo tiene otro producto
     * @throws SQLException si ocurre un error con la base de datos
     */
    public boolean actualizar(Producto p) throws SQLException {
        if (existeCodigo(p.getCodigo(), p.getIdProducto())) {
            return false;
        }
        String sql = "UPDATE producto SET codigo=?, nombre=?, precio_costo=?, precio_venta=?, stock=? "
                   + "WHERE id_producto=?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getCodigo().trim());
            ps.setString(2, p.getNombre().trim());
            ps.setDouble(3, p.getPrecioCosto());
            ps.setDouble(4, p.getPrecioVenta());
            ps.setInt(5, p.getStock());
            ps.setInt(6, p.getIdProducto());
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Elimina un producto (Delete).
     * @param idProducto identificador del producto
     * @return true si se eliminó
     * @throws SQLException si el producto ya tiene ventas (llave foránea) u otro error
     */
    public boolean eliminar(int idProducto) throws SQLException {
        String sql = "DELETE FROM producto WHERE id_producto = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idProducto);
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Consulta productos por código o nombre (Read). Con filtro vacío trae todos.
     * @param filtro texto a buscar dentro del código o del nombre
     * @return lista de productos encontrados
     * @throws SQLException si ocurre un error con la base de datos
     */
    public List<Producto> listar(String filtro) throws SQLException {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM producto WHERE codigo LIKE ? OR nombre LIKE ? ORDER BY nombre";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String patron = "%" + filtro.trim() + "%";
            ps.setString(1, patron);
            ps.setString(2, patron);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(convertir(rs));
                }
            }
        }
        return lista;
    }

    /**
     * Busca un producto por su código exacto (se usa al vender).
     * @param codigo código del producto
     * @return el producto, o null si no existe
     * @throws SQLException si ocurre un error con la base de datos
     */
    public Producto buscarPorCodigo(String codigo) throws SQLException {
        String sql = "SELECT * FROM producto WHERE codigo = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, codigo.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return convertir(rs);
                }
            }
        }
        return null;
    }

    /** Revisa si el código ya lo usa otro producto distinto de idExcluir. */
    private boolean existeCodigo(String codigo, int idExcluir) throws SQLException {
        String sql = "SELECT COUNT(*) FROM producto WHERE codigo = ? AND id_producto <> ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, codigo.trim());
            ps.setInt(2, idExcluir);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }

    private Producto convertir(ResultSet rs) throws SQLException {
        return new Producto(rs.getInt("id_producto"), rs.getString("codigo"),
                rs.getString("nombre"), rs.getDouble("precio_costo"),
                rs.getDouble("precio_venta"), rs.getInt("stock"));
    }
}
