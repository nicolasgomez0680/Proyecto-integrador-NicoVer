package com.nicover.repositorio;

import com.nicover.config.Conexion;
import com.nicover.modelo.Cliente;
import com.nicover.modelo.DetalleVenta;
import com.nicover.modelo.Usuario;
import com.nicover.modelo.Venta;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Repositorio de ventas: guarda una venta completa (venta + detalles +
 * descuento de stock) y consulta las ventas registradas.
 */
public class VentaRepository {

    /**
     * Registra la venta en una sola transacción: inserta la venta, inserta cada
     * detalle y descuenta el stock en MySQL. Si algo falla, se deshace todo.
     * @param venta venta ya calculada y con el pago registrado
     * @return true si se guardó completa; false si el stock fue insuficiente
     * @throws SQLException si ocurre un error con la base de datos
     */
    public boolean registrarVenta(Venta venta) throws SQLException {
        String sqlVenta = "INSERT INTO venta (fecha, id_cliente, id_usuario, subtotal, iva, total, "
                        + "metodo_pago, monto_recibido, cambio) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String sqlStock = "UPDATE producto SET stock = stock - ? WHERE id_producto = ? AND stock >= ?";
        String sqlDetalle = "INSERT INTO detalle_venta (id_venta, id_producto, cantidad, "
                          + "precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?)";

        try (Connection con = Conexion.getConexion()) {
            con.setAutoCommit(false);
            try (PreparedStatement psVenta = con.prepareStatement(sqlVenta, Statement.RETURN_GENERATED_KEYS);
                 PreparedStatement psStock = con.prepareStatement(sqlStock);
                 PreparedStatement psDetalle = con.prepareStatement(sqlDetalle)) {

                psVenta.setTimestamp(1, Timestamp.valueOf(venta.getFecha()));
                psVenta.setInt(2, venta.getCliente().getIdCliente());
                psVenta.setInt(3, venta.getUsuario().getIdUsuario());
                psVenta.setDouble(4, venta.getSubtotal());
                psVenta.setDouble(5, venta.getIva());
                psVenta.setDouble(6, venta.getTotal());
                psVenta.setString(7, venta.getMetodoPago());
                psVenta.setDouble(8, venta.getMontoRecibido());
                psVenta.setDouble(9, venta.getCambio());
                psVenta.executeUpdate();

                try (ResultSet keys = psVenta.getGeneratedKeys()) {
                    keys.next();
                    venta.setIdVenta(keys.getInt(1));
                }

                for (DetalleVenta d : venta.getDetalles()) {
                    psStock.setInt(1, d.getCantidad());
                    psStock.setInt(2, d.getProducto().getIdProducto());
                    psStock.setInt(3, d.getCantidad());
                    if (psStock.executeUpdate() == 0) {   // no había stock suficiente
                        con.rollback();
                        return false;
                    }
                    psDetalle.setInt(1, venta.getIdVenta());
                    psDetalle.setInt(2, d.getProducto().getIdProducto());
                    psDetalle.setInt(3, d.getCantidad());
                    psDetalle.setDouble(4, d.getPrecioUnitario());
                    psDetalle.setDouble(5, d.getSubtotal());
                    psDetalle.executeUpdate();
                }
                con.commit();
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        }
        // Se mantiene sincronizado el stock de los objetos en memoria
        for (DetalleVenta d : venta.getDetalles()) {
            d.getProducto().descontarStock(d.getCantidad());
        }
        return true;
    }

    /**
     * Consulta las ventas registradas, de la más reciente a la más antigua.
     * @return lista de ventas con el nombre del cliente y del usuario
     * @throws SQLException si ocurre un error con la base de datos
     */
    public List<Venta> listar() throws SQLException {
        List<Venta> lista = new ArrayList<>();
        String sql = "SELECT v.id_venta, v.fecha, v.subtotal, v.iva, v.total, v.metodo_pago, "
                   + "c.nombre AS cliente, u.nombre_usuario AS usuario "
                   + "FROM venta v JOIN cliente c ON v.id_cliente = c.id_cliente "
                   + "JOIN usuario u ON v.id_usuario = u.id_usuario ORDER BY v.fecha DESC";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Venta v = new Venta();
                v.setIdVenta(rs.getInt("id_venta"));
                v.setFecha(rs.getTimestamp("fecha").toLocalDateTime());
                v.setSubtotal(rs.getDouble("subtotal"));
                v.setIva(rs.getDouble("iva"));
                v.setTotal(rs.getDouble("total"));
                v.setMetodoPago(rs.getString("metodo_pago"));
                Cliente c = new Cliente();
                c.setNombre(rs.getString("cliente"));
                v.setCliente(c);
                Usuario u = new Usuario();
                u.setNombreUsuario(rs.getString("usuario"));
                v.setUsuario(u);
                lista.add(v);
            }
        }
        return lista;
    }
}
