package com.nicover.repositorio;

import com.nicover.config.Conexion;
import com.nicover.modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Repositorio de usuarios: se encarga de consultar la tabla usuario en MySQL.
 */
public class UsuarioRepository {

    /**
     * Busca un usuario con ese nombre y clave.
     * La clave escrita se cifra con SHA-256 antes de compararla con la guardada.
     * @param nombreUsuario nombre de usuario digitado
     * @param clave clave digitada (sin cifrar)
     * @return el Usuario si las credenciales son correctas; null si no coinciden
     * @throws SQLException si ocurre un error con la base de datos
     */
    public Usuario autenticar(String nombreUsuario, String clave) throws SQLException {
        String sql = "SELECT id_usuario, nombre_usuario, clave, rol FROM usuario "
                   + "WHERE nombre_usuario = ? AND clave = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nombreUsuario);
            ps.setString(2, Usuario.encriptarClave(clave));
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Usuario(rs.getInt("id_usuario"), rs.getString("nombre_usuario"),
                            rs.getString("clave"), rs.getString("rol"));
                }
            }
        }
        return null;
    }
}
