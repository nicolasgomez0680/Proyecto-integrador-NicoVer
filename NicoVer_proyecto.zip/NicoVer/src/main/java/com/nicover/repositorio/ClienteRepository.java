package com.nicover.repositorio;

import com.nicover.config.Conexion;
import com.nicover.modelo.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Repositorio de clientes: realiza el CRUD sobre la tabla cliente.
 */
public class ClienteRepository {

    /**
     * Inserta un cliente nuevo (Create).
     * @param c cliente a guardar
     * @return true si se guardó; false si ya existe un cliente con ese documento
     * @throws SQLException si ocurre un error con la base de datos
     */
    public boolean guardar(Cliente c) throws SQLException {
        if (existeDocumento(c.getDocumento(), 0)) {
            return false;
        }
        String sql = "INSERT INTO cliente (documento, nombre, telefono, direccion, acepta_datos) "
                   + "VALUES (?, ?, ?, ?, ?)";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getDocumento().trim());
            ps.setString(2, c.getNombre().trim());
            ps.setString(3, c.getTelefono());
            ps.setString(4, c.getDireccion());
            ps.setBoolean(5, c.isAceptaDatos());
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Modifica un cliente existente (Update).
     * @param c cliente con los datos nuevos (debe traer su idCliente)
     * @return true si se actualizó; false si el documento ya lo tiene otro cliente
     * @throws SQLException si ocurre un error con la base de datos
     */
    public boolean actualizar(Cliente c) throws SQLException {
        if (existeDocumento(c.getDocumento(), c.getIdCliente())) {
            return false;
        }
        String sql = "UPDATE cliente SET documento=?, nombre=?, telefono=?, direccion=?, acepta_datos=? "
                   + "WHERE id_cliente=?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, c.getDocumento().trim());
            ps.setString(2, c.getNombre().trim());
            ps.setString(3, c.getTelefono());
            ps.setString(4, c.getDireccion());
            ps.setBoolean(5, c.isAceptaDatos());
            ps.setInt(6, c.getIdCliente());
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Elimina un cliente (Delete).
     * @param idCliente identificador del cliente
     * @return true si se eliminó
     * @throws SQLException si el cliente ya tiene ventas (llave foránea) u otro error
     */
    public boolean eliminar(int idCliente) throws SQLException {
        String sql = "DELETE FROM cliente WHERE id_cliente = ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idCliente);
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Consulta clientes por documento o nombre (Read). Con filtro vacío trae todos.
     * @param filtro texto a buscar
     * @return lista de clientes encontrados
     * @throws SQLException si ocurre un error con la base de datos
     */
    public List<Cliente> listar(String filtro) throws SQLException {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT * FROM cliente WHERE documento LIKE ? OR nombre LIKE ? ORDER BY nombre";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            String patron = "%" + filtro.trim() + "%";
            ps.setString(1, patron);
            ps.setString(2, patron);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Cliente(rs.getInt("id_cliente"), rs.getString("documento"),
                            rs.getString("nombre"), rs.getString("telefono"),
                            rs.getString("direccion"), rs.getBoolean("acepta_datos")));
                }
            }
        }
        return lista;
    }

    /** Revisa si el documento ya lo usa otro cliente distinto de idExcluir. */
    private boolean existeDocumento(String documento, int idExcluir) throws SQLException {
        String sql = "SELECT COUNT(*) FROM cliente WHERE documento = ? AND id_cliente <> ?";
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, documento.trim());
            ps.setInt(2, idExcluir);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        }
    }
}
