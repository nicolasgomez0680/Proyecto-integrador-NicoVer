# NicoVer

Sistema de escritorio en Java para la gestión de ventas, inventario y clientes en un comercio minorista.
Proyecto integrador – Tecnología en Sistemas de Información, Grupo 327, Institución Universitaria Antonio José Camacho.

## Integrantes
- Verónica Rosero Waitoto
- Nicolás Arrechea Gómez

## Descripción
NicoVer reemplaza el registro manual (cuadernos y hojas de cálculo) de una tienda de barrio. Permite:
- Iniciar sesión con rol (Administrador o Cajero).
- CRUD de **productos** (solo administrador) y de **clientes**, con autorización de datos (Ley 1581 de 2012).
- **Registrar ventas**: carrito, IVA 19 %, método de pago, cambio y descuento automático de stock.
- Consultar las ventas realizadas.

## Tecnologías
Java 17, Swing, JDBC, MySQL 8, Maven. Arquitectura por capas (MVC).

## Estructura de paquetes
```
com.nicover
├── Main.java
├── config        Conexion
├── modelo        Usuario, Cliente, Producto, Venta, DetalleVenta
├── repositorio   UsuarioRepository, ClienteRepository, ProductoRepository, VentaRepository
├── controlador   LoginController, ClienteController, ProductoController, VentaController
└── vista         FrmLogin, FrmMenu, FrmProductos, FrmClientes, FrmVentas
```

## Cómo ejecutarlo
1. Instalar **JDK 17+**, **MySQL 8** y **Visual Studio Code** con la extensión *Extension Pack for Java*.
2. Crear la base de datos: abrir `sql/nicover_db.sql` en MySQL Workbench y ejecutarlo completo
   (o `mysql -u root -p < sql/nicover_db.sql`).
3. Copiar `db.properties.example` como `db.properties` (en la raíz del proyecto) y escribir la contraseña de su MySQL.
4. Abrir la carpeta del proyecto en VS Code (Maven descarga el conector JDBC automáticamente).
5. Abrir `src/main/java/com/nicover/Main.java` y pulsar **Run** (o `mvn compile exec:java -Dexec.mainClass=com.nicover.Main`).

## Usuarios de prueba
| Usuario | Clave | Rol |
|---|---|---|
| admin | admin123 | Administrador |
| cajero | caja123 | Cajero |

## Documentación
El documento del proyecto y el archivo `.drawio` (diagrama de clases, métodos entrada-proceso-salida y mockups) están en la carpeta `docs/`.
