-- ============================================================
-- NicoVer - Script de base de datos (MySQL 8)
-- Ejecutar completo en MySQL Workbench o con:
--   mysql -u root -p < sql/nicover_db.sql
-- ============================================================
DROP DATABASE IF EXISTS nicover_db;
CREATE DATABASE nicover_db CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE nicover_db;

-- Usuarios del sistema (la clave se guarda cifrada con SHA-256)
CREATE TABLE usuario (
    id_usuario     INT AUTO_INCREMENT PRIMARY KEY,
    nombre_usuario VARCHAR(50)  NOT NULL UNIQUE,
    clave          VARCHAR(64)  NOT NULL,
    rol            VARCHAR(20)  NOT NULL,
    CONSTRAINT chk_usuario_rol CHECK (rol IN ('ADMINISTRADOR', 'CAJERO'))
);

CREATE TABLE producto (
    id_producto  INT AUTO_INCREMENT PRIMARY KEY,
    codigo       VARCHAR(30)    NOT NULL UNIQUE,
    nombre       VARCHAR(100)   NOT NULL,
    precio_costo DECIMAL(10,2)  NOT NULL,
    precio_venta DECIMAL(10,2)  NOT NULL,
    stock        INT            NOT NULL DEFAULT 0,
    CONSTRAINT chk_producto_precios CHECK (precio_costo >= 0 AND precio_venta >= 0),
    CONSTRAINT chk_producto_stock CHECK (stock >= 0)
);

CREATE TABLE cliente (
    id_cliente    INT AUTO_INCREMENT PRIMARY KEY,
    documento     VARCHAR(20)  NOT NULL UNIQUE,
    nombre        VARCHAR(100) NOT NULL,
    telefono      VARCHAR(20),
    direccion     VARCHAR(150),
    acepta_datos  TINYINT(1)   NOT NULL DEFAULT 0   -- autorización Ley 1581 de 2012
);

CREATE TABLE venta (
    id_venta       INT AUTO_INCREMENT PRIMARY KEY,
    fecha          DATETIME      NOT NULL,
    id_cliente     INT           NOT NULL,
    id_usuario     INT           NOT NULL,
    subtotal       DECIMAL(12,2) NOT NULL,
    iva            DECIMAL(12,2) NOT NULL,
    total          DECIMAL(12,2) NOT NULL,
    metodo_pago    VARCHAR(30)   NOT NULL,
    monto_recibido DECIMAL(12,2) NOT NULL,
    cambio         DECIMAL(12,2) NOT NULL,
    CONSTRAINT fk_venta_cliente FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente),
    CONSTRAINT fk_venta_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);

CREATE TABLE detalle_venta (
    id_detalle      INT AUTO_INCREMENT PRIMARY KEY,
    id_venta        INT           NOT NULL,
    id_producto     INT           NOT NULL,
    cantidad        INT           NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    subtotal        DECIMAL(12,2) NOT NULL,
    CONSTRAINT fk_detalle_venta FOREIGN KEY (id_venta) REFERENCES venta(id_venta) ON DELETE CASCADE,
    CONSTRAINT fk_detalle_producto FOREIGN KEY (id_producto) REFERENCES producto(id_producto),
    CONSTRAINT chk_detalle_cantidad CHECK (cantidad > 0)
);

-- ------------------------------------------------------------
-- Datos de prueba
-- Usuarios: admin / admin123   y   cajero / caja123
-- ------------------------------------------------------------
INSERT INTO usuario (nombre_usuario, clave, rol) VALUES
('admin',  '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'ADMINISTRADOR'),
('cajero', '682b1787210953a4a1f91a9eed757bc3b3e8827fd464a2d970db063a24b1526a', 'CAJERO');

INSERT INTO producto (codigo, nombre, precio_costo, precio_venta, stock) VALUES
('P001', 'Arroz 500 g',        1800, 2500, 40),
('P002', 'Aceite 1 L',         7500, 9800, 25),
('P003', 'Leche entera 1 L',   3200, 4200, 30),
('P004', 'Huevos (cubeta x30)', 14000, 17500, 12);

INSERT INTO cliente (documento, nombre, telefono, direccion, acepta_datos) VALUES
('1000000001', 'Cliente de mostrador', '0000000', 'N/A', 1),
('1114555666', 'María Fernanda Ruiz',  '3001234567', 'Calle 5 # 10-20', 1);
